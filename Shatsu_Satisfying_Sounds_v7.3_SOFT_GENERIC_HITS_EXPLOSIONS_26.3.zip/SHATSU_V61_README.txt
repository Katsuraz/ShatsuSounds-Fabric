SHATSU v6.1 — VANILLA MOB IDENTITY RESTORED
Minecraft Java 26.3 / Fabric, resource pack

Why this version exists
Shatsu v6.0 assigned some unrelated generic monster recordings to zombies, skeletons,
endermen, ghasts, blazes, spiders and other creatures. That erased their vanilla identities.
This version removes those creature-event overrides. Minecraft supplies its original
voices, attacks, hurt and death sounds directly; no Mojang audio is repackaged.
Restored vanilla mob sound events: 303
All Shatsu v6.1 Minecraft event overrides: 1028
Still includes 329 pre-v6 Shatsu event overrides.

PRESERVED FROM v6:
- All v6 block material mappings and non-creature sound events
- Firework sounds, TNT, thunder, machinery, equipment, portals and world interactions
- Existing Shatsu inventory opening sound and its six audio clips, byte-for-byte
- Existing Sounds UI event definitions, Clangor event definitions, custom blocks map
- Existing drinking sounds, including generic drinking and honey
- Food sound events and 95 v4.6 recorded-food clips (food-aware mod still experimental)

NOT REPLACED IN v6.1:
- Original mob vocalizations / attack identity sounds now use Minecraft defaults
- Musical note blocks, music discs, most ambient loops and goat-horn melodies
  (intentional: these require appropriate authentic recordings, not generic reassignment).
- Existing inventory-opening sound remains unchanged.

INSTALL:
1. Disable old full Shatsu v6.0 and other full Shatsu resource packs.
2. Put this complete v6.1 resource pack ZIP inside instance/resourcepacks.
3. Enable v6.1 above other texture/resource packs and press F3+T.
4. Keep your previously installed compatible Clangor, Sounds and Custom Block Sounds mods.
5. If a separate creature sound pack is active ABOVE Shatsu, it may still alter mobs.
6. Do not install the old Shatsu Food Audio experimental jar; its playback is unverified.

TEST /playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 1 1
TEST /playsound minecraft:entity.enderman.ambient master @s ~ ~ ~ 1 1
TEST /playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 1 1
All validation is offline; in-game playback is not independently verified.
