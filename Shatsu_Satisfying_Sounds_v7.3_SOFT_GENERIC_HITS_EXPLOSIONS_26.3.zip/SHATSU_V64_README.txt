SHATSU SATISFYING SOUNDS v6.4 — CRISP WEAPONS + CELEBRATION (MINECRAFT JAVA 26.3)

IMPROVED
- Bow fires: stronger pluck and string release with a distinct short arrow air-rush after the snap.
- Crossbow fires: more mechanical, sharper bolt launch and an air-rush tail (not a gunshot).
- Arrow impacts: distinct block and player impacts, short enough to avoid rapid-fire clutter.
- Skeleton arrow shots: now use a lighter variant of the redesigned bow firing release.
- Trident: throw, impact, ground, return, Riptide I/II/III and thunder sound redesigned with brighter transients.
- Crossbow charging, Quick Charge I-III, and Clangor bow/trident charge and trident swing sounds updated.
- Challenge advancement: a new ~3.4-second G-major celebratory fanfare with a warm ringing resolution.
- Custom command 'playsound shatsu7:advancement.challenge master @s ~ ~ ~ 1 1' also plays the longer fanfare.

IMPORTANT ABOUT MOBS
- Vanilla Minecraft mob voices have deliberately not been replaced in this build. The user requested
  retro versions *of the original voices*, not generic replacement monster noises. Those original
  audio assets are absent from the existing Shatsu packs and CC0 libraries.
- Use Shatsu_Mob_Voice_One_Click_Exporter.zip (provided separately), run its included BAT on your
  Minecraft PC, and upload the resulting Shatsu_Original_Mob_Sounds_26.3.zip. This allows the next
  pack revision to bitcrush and warm-saturate each actual original voice while retaining identity.

ABOUT ARROWS
- Vanilla Java supports bow-arrow firing and impact events but NO independent continuous
  mid-air projectile flight sound event. Arrow rush is embedded in the release sound, so it plays
  automatically whenever bow/crossbow fires. True distance-based passing arrows require a mod.

INSTALL
- Use this entire ZIP as a single resource pack in .minecraft/resourcepacks (do NOT unzip).
- Disable older full Shatsu packs instead of stacking conflicting overrides.
- F3+T reloads. Ensure resource pack is enabled at high priority.
- A lightweight overlay for existing v6.3 users is provided separately.

AUDIO SOURCES
- New weapon samples use user's CC0 SFX100 v2 and 150 game effect sounds libraries, layered with original synthesis.
- New achievement fanfare is an original generated composition, not an existing copyrighted melody.
- Already liked inventory-open, food/drink, and Elytra are preserved without changes.
- In-game event playback is not independently verified from this environment; JSON/file mapping was audited.
