Shatsu v6.5 — Crisp Weapon Release Fix (Minecraft Java 26.3)

This update changes only the bow, crossbow and trident sound events.
Existing arrow impacts, inventory sounds, food, Elytra, and mob voices remain untouched.

Install either the full pack (replaces v6.4), OR the overlay (above v6.4). Do not enable both.
F3+T reloads resource packs. If testing the overlay, place it at the TOP.

Direct checks:
/playsound minecraft:entity.arrow.shoot master @s ~ ~ ~ 1 1
/playsound minecraft:item.crossbow.shoot master @s ~ ~ ~ 1 1
/playsound minecraft:item.trident.throw master @s ~ ~ ~ 1 1
/playsound shatsu9:bow_release master @s ~ ~ ~ 1 1
/playsound shatsu9:crossbow_release master @s ~ ~ ~ 1 1
/playsound shatsu9:trident_throw master @s ~ ~ ~ 1 1

If shatsu9 direct tests work but vanilla event tests do not, check pack priority and mod conflicts.
If both commands work but weapon use does not, a mod may replace actual weapon events.
A resource pack cannot invent new real-time actions like bow draw or sustained flying-arrow audio.
