SHATSU SOUNDS v5.0 - WORLD AUDIO EXPANSION
Minecraft Java 26.3 | Fabric resource pack | 4 new CC0 archives

WHAT CHANGED
8 distinct firework events; TNT priming/normal explosions; lightning
redstone machinery and sculk clicks; enchanting, beacons, portals
shields/tridents; boat and water interactions; carefully selected creature movement.
New sounds are edited from your 4 CC0 sound ZIP uploads.

WHAT WAS NOT ALTERED
Every sound from Shatsu v4.6 that previously worked is preserved byte-for-byte:
Clangor equips/swings, tool sounds, doors, chests, inventory, block sounds,
food, all drinking effects and all prior sounds/definitions.
Existing Sounds mod ui.json and other configuration files are not changed.
Rain, music, note blocks, mob ambient voices, and other sounds with no suitable recordings remain vanilla.

INSTALLATION - FULL PACK
1. Put Shatsu_Satisfying_Sounds_v5.0_COMPLETE_26.3.zip in resourcepacks.
2. Disable older complete Shatsu packs (v4.6, etc).
3. Enable v5.0 and press F3+T to reload.
4. Keep Clangor and Custom Block Sounds as before. Do not install the old experimental Food Audio JAR.

ALTERNATIVE: PATCH OVER EXISTING PACK
Enable Shatsu_v5.0_NEW_WORLD_SOUNDS_OVERLAY_26.3.zip ABOVE Shatsu v4.6.
Do not enable the overlay and full v5.0 together.

TEST QUICKLY
/playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 1 1
/playsound minecraft:block.piston.extend master @s ~ ~ ~ 1 1
/playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
/playsound minecraft:entity.slime.squish master @s ~ ~ ~ 1 1

This is an offline-validated resource pack, NOT an in-game runtime test.
Specific event activation can still vary with other mods or resource-pack priority.

See SHATSU_V5_AUDIO_SOURCE_MANIFEST.csv for per-file provenance and SHATSU_V5_CC0_CREDITS.txt for licenses.
