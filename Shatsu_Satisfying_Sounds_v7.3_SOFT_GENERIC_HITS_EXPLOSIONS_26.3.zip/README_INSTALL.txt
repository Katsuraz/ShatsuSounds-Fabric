Shatsu Satisfying Sounds v4.3 – Kenney Fusion (Fabric 26.3)

LICENSED AUDIO SOURCES
Kenney Interface Sounds 1.0 (100 CC0 samples) — https://kenney.nl/assets/interface-sounds
Kenney Impact Sounds 1.0 (130 CC0 samples) — https://kenney.nl/assets/impact-sounds
Both archives were uploaded by the user and contained License.txt confirming Creative Commons Zero (CC0). Attribution is appreciated, not required. Original Shatsu v4.2 audio is preserved and remixed with selected Kenney sound layers. Not affiliated with Kenney. No third-party eating recordings used.

FEATURES
Preserved v4.2 Clangor sound definitions, Sounds UI events and 1,047 Custom Block Sounds block mappings. Real Kenney impact layers were added to final breaks and mining hits with individual per-block character preserved. Doors/trapdoors/chests have enhanced latch and material sounds, inventory and typing use Kenney clicks, tool swings remain largely unchanged but hits are improved. Stone retains its softer tone. Eating remains mainly Shatsu-original.

INSTALL
Close Minecraft. Backup config/sounds/ui.json. Extract complete installer into instance root with mods/, config/, resourcepacks/. Enable v4.3 above all old Shatsu packs, disable older Shatsu packs. Keep Sounds, Custom Block Sounds and Clangor Fabric mods, and disable conflicting built-in Clangor resource pack if needed. Only ui.json is included; all other Sounds configs stay as you set them. Press F3+T to reload. No need to install the original Kenney ZIPs.

All sound references and ZIP files checked offline. Not yet verified in actual Minecraft gameplay.
