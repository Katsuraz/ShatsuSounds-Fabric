SHATSU SATISFYING SOUNDS v6.0 — FULL WORLD SFX OVERHAUL
Minecraft Java Edition 26.3 | Fabric | Resource Pack

WHAT IS ACTUALLY OVERRIDDEN
1331 vanilla sound events in total: 329 retained from v5.0, 1002 added.
445 additional material-specific block events mapped to existing Shatsu recordings.
102 newly edited Ogg clips from the CC0 source archives you supplied.
Custom Shatsu block events, Clangor event maps (137 events), Sounds mod UI events (11),
Custom Block Sounds mappings and food sound variants are preserved from v5.0.

NEW AREAS
Nearly every standard block material action incl. Minecraft 26.3's new materials;
additional doors, containers, redstone and workstations; equipment and item interactions;
monster attacks, hurts, movement, physical effects, flying, ranged attacks;
weather, rain and water, select biome/world ambience; refreshed vanilla UI.

WHAT IS NOT REPLACED
Minecraft's licensed music/discs, most animal voice calls, musical note block instrument
samples, or eating/drinking audio already in v5.0. The existing inventory-opening sound and its audio variants are preserved byte-for-byte. These need authentic species/instrument
recordings or reliable food-aware modding. Shatsu 6 does not claim to replace all 1991
vanilla events and does not install experimental mod JARs. Ambient loops are experimental.

INSTALL
1. Put Shatsu_Satisfying_Sounds_v6.0_FULL_WORLD_OVERHAUL_26.3.zip in your instance's resourcepacks folder.
2. Disable older full Shatsu packs (v5.0, v4.6, etc), enable ONLY v6.0.
3. Keep the same mods Clangor, Custom Block Sounds and Sounds that worked with v5.
4. Press F3 + T to reload sound resources.
5. Optional: If you prefer the old ambience, disable the ambient preset in your resource priority; this pack does not add a runtime settings menu.

SPECIAL NOTE: the previously released Shatsu Food Audio experimental JAR did not reliably
work and is not included. Removing that JAR is recommended.

TEST QUICKLY (client game with cheats)
/playsound minecraft:weather.rain master @s ~ ~ ~ 1 1
/playsound minecraft:block.shelf_mushroom.break master @s ~ ~ ~ 1 1
/playsound minecraft:item.book.page_turn master @s ~ ~ ~ 1 1
/playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 1 1
/playsound minecraft:entity.spider.step master @s ~ ~ ~ 1 1
/playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 1 1

All checks are OFFLINE ONLY. Actual playback and gameplay triggers are unverified.
See SHATSU_V6_EVENT_CHANGELOG.csv & SHATSU_V6_SOURCE_TRACKING.csv for a precise audit.
