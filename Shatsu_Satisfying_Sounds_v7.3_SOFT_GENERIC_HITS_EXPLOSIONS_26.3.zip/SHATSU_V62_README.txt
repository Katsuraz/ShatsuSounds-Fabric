SHATSU SATISFYING SOUNDS v6.2 — GLIDING WIND / VANILLA MOBS
Minecraft Java 26.3, Fabric resource pack.

FIXED IN 6.2:
- Elytra flight event minecraft:item.elytra.flying now plays three 8-second airy wind textures,
  instead of two 0.45-second wing-flapping impacts.
- Wind is derived from the CC0 SFX100 v2 recorded air samples supplied by the user.
- Original wing-flap audio is removed from this full resource pack.
- Existing Minecraft flight sound engine continues to control the level/pitch by velocity.
- Elytra equip is unchanged: a little cloth rustle when putting it on makes sense.

INHERITED FROM 6.1:
- 303 new v6 creature event overrides were removed, restoring authentic vanilla mob voices.
- Preserves Shatsu v5 fireworks, material breaks, tools, Clangor, inventory and UI mappings,
  item-specific food audio asset library, door sounds, and the drinking sounds you liked.
- Original opening-inventory sound and all six variations unchanged bit-for-bit.
- Do NOT add the experimental Shatsu Food Audio JAR: food-aware playback is unverified.

INSTALL:
1. Disable previous full Shatsu v6.0 and v6.1 resource packs (don't stack them).
2. Put the v6.2 resource pack ZIP in your instance/resourcepacks folder.
3. Enable in-game; F3+T reloads the resources.
4. Keep Clangor / Sounds / Custom Block Sounds Fabric mods as currently installed.
5. Test gliding for at least 10 seconds, with and without fireworks; Minecraft adjusts
   Elytra sound by flight speed. Also check zombie sounds and opening inventory.

EXPERIMENTAL NOTE: File references and audio integrity were verified offline;
we cannot independently confirm Minecraft 26.3 playback inside the game here.

SOUND SOURCE AND LICENSE:
'SFX100 v2' air_01 and air_02 (CC0) from the user-uploaded sfx_100_v2.zip.
The original recordings were spectrally balanced and layered into seamless wind loops.
No copyrighted Minecraft original sounds are repackaged.
